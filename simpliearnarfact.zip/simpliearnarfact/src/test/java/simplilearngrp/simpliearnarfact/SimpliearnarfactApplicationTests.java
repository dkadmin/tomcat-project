package simplilearngrp.simpliearnarfact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpliearnarfactApplicationTests {

	@Test
	void contextLoads() {
	}

}
